define({
  "_themeLabel": "Tema panoa",
  "_layout_default": "Zadani izgled",
  "_layout_right": "Pravi izgled"
});