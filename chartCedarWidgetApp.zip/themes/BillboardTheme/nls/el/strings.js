define({
  "_themeLabel": "Θέμα Πίνακας ανακοινώσεων",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_right": "Δεξιά διάταξη"
});