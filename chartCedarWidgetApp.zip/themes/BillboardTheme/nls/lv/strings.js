define({
  "_themeLabel": "Reklāmas zonas dizains",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_right": "Pareizais izkārtojums"
});