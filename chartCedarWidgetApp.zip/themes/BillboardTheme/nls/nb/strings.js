define({
  "_themeLabel": "Reklametavletema",
  "_layout_default": "Standardoppsett",
  "_layout_right": "Høyre-oppsett"
});