define({
  "_themeLabel": "Motyw na billboardzie",
  "_layout_default": "Kompozycja domyślna",
  "_layout_right": "Kompozycja prawostronna"
});