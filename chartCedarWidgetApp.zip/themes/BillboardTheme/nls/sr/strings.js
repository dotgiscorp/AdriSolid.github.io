define({
  "_themeLabel": "Tema bilborda",
  "_layout_default": "Podrazumevani raspored",
  "_layout_right": "Desni raspored"
});