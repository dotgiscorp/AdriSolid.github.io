define({
  root: ({
    _widgetLabel: "Bar Chart Cedar",
    selectLayer: "Select a layer",
    selectXField: "Select X Field",
    selectYField: "Select Y Field",
    selectChart: "Select chart type",
    execute: "Execute",
    extent: "Filter by extent"
  }),
  "es": 1
});